﻿namespace LSPGood;

internal class BackupSource
{
    public virtual void ReadFiles()
    {
        Console.WriteLine("Получение файлов.");
    }

    public virtual int GetSize()
    {
        return 0;
    }
}